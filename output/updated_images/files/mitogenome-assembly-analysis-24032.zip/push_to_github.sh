#!/usr/bin/env bash
# push_to_github.sh
# -----------------
# Creates the GitHub repository and pushes all files.
# Usage: GITHUB_TOKEN=ghp_xxx GITHUB_USER=yourname bash push_to_github.sh
#
# Requires: git, curl, python3 (for base64 encoding via API)
# The token needs the 'repo' scope.

set -euo pipefail

REPO_NAME="mitogenome-assembly-analysis-24032"
REPO_DESC="Mitogenome assembly quality analysis for Naturalis AVITI run 20260428_AV250703_24032-5021000_28_04_2026"

if [[ -z "${GITHUB_TOKEN:-}" ]]; then
  echo "ERROR: set GITHUB_TOKEN before running this script."
  exit 1
fi
if [[ -z "${GITHUB_USER:-}" ]]; then
  # Try to get it from the API
  GITHUB_USER=$(curl -sf -H "Authorization: token $GITHUB_TOKEN" https://api.github.com/user | python3 -c "import sys,json; print(json.load(sys.stdin)['login'])")
  echo "Detected GitHub user: $GITHUB_USER"
fi

# 1. Create repository
echo "Creating repository $GITHUB_USER/$REPO_NAME ..."
curl -sf -X POST \
  -H "Authorization: token $GITHUB_TOKEN" \
  -H "Accept: application/vnd.github+json" \
  https://api.github.com/user/repos \
  -d "{\"name\":\"$REPO_NAME\",\"description\":\"$REPO_DESC\",\"private\":false,\"auto_init\":false}" \
  > /dev/null
echo "Repository created."

# 2. Init git and push
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

git init -q
git checkout -b main
git add .
git rm --cached push_to_github.sh 2>/dev/null || true   # don't commit the push script itself
git config user.email "analysis@naturalis.nl"
git config user.name "$GITHUB_USER"
git commit -q -m "Initial commit: mitogenome assembly analysis run 24032"

REMOTE="https://${GITHUB_TOKEN}@github.com/${GITHUB_USER}/${REPO_NAME}.git"
git remote add origin "$REMOTE"
git push -q -u origin main

echo ""
echo "Done! Repository available at:"
echo "  https://github.com/$GITHUB_USER/$REPO_NAME"
